import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Hero from './sections/Hero';
import About from './sections/About';
import Skills from './sections/Skills';
import Experience from './sections/Experience';
import Certifications from './sections/Certifications';
import Articles from './sections/Articles';
import Contact from './sections/Contact';

export default function App() {
  return <><a href="#main-content" className="skip-link">Skip to content</a><Navbar /><main id="main-content"><Hero /><About /><Skills /><Experience /><Certifications /><Articles /><Contact /></main><Footer /></>;
}
