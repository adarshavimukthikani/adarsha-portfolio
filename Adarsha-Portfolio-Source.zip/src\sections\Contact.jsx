import { useState } from 'react';
import { ArrowUpRight, Check, Copy, Phone } from 'lucide-react';
import { profile } from '../data/profile';
import { Eyebrow, Reveal, Spark } from '../components/Primitives';

export default function Contact() {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const copyEmail = async () => {
    try { await navigator.clipboard.writeText(profile.email); setCopied(true); setCopyError(false); }
    catch { setCopyError(true); }
  };
  return <section id="contact" className="contact-section shell section-pad"><Reveal><div className="contact-card"><Eyebrow number="06">GOOD CONVERSATIONS START SOMEWHERE</Eyebrow><div className="contact-top"><h2>Have a thought?<br />Let’s make<br /><span className="contact-italic">a connection.</span></h2><div className="contact-art" aria-hidden="true"><div className="contact-orb" /><Spark /><span className="contact-small-orb" /></div></div>
    <div className="contact-bottom"><div><p className="contact-intro">An idea, a learning opportunity, or a fresh perspective.<br />I’d love to hear from you.</p><div className="email-row"><a className="contact-email" href={`mailto:${profile.email}`}>{profile.email}<ArrowUpRight aria-hidden="true" size={23} /></a><button className="copy-button icon-button" type="button" onClick={copyEmail} aria-label={copied ? 'Email address copied' : 'Copy email address'}>{copied ? <Check size={17} /> : <Copy size={17} />}</button></div><span className="copy-status" role="status" aria-live="polite">{copied ? 'Email address copied.' : copyError ? 'Please select the email address to copy it.' : ''}</span></div><div className="contact-socials"><a href={profile.linkedin} target="_blank" rel="noopener noreferrer"><span className="linkedin-mark" aria-hidden="true">in</span>LinkedIn<ArrowUpRight size={17} aria-hidden="true" /></a><a href={profile.medium} target="_blank" rel="noopener noreferrer"><span className="medium-mark" aria-hidden="true">●</span>Medium<ArrowUpRight size={17} aria-hidden="true" /></a><a href={profile.phoneHref}><Phone size={16} aria-hidden="true" />{profile.phone}<ArrowUpRight size={17} aria-hidden="true" /></a></div></div>
  </div></Reveal></section>;
}
