import { ArrowDown, ArrowUpRight, MoveDown } from 'lucide-react';
import { m as motion, useReducedMotion } from 'motion/react';
import { asset } from '../data/assets';
import { profile } from '../data/profile';
import { Spark } from '../components/Primitives';

export default function Hero() {
  const reduced = useReducedMotion();
  return <section id="home" className="hero shell">
    <div className="hero-topline mono"><span><span className="tiny-dot" />A PERSONAL EXPLORATION</span><span>BUSINESS × CREATIVITY</span></div>
    <div className="hero-grid">
      <motion.div className="hero-copy" initial={reduced ? false : {opacity:0,y:25}} animate={{opacity:1,y:0}} transition={{duration:0.85,ease:[0.22,1,0.36,1]}}>
        <p className="hero-hello">Hi, I’m {profile.name}<span className="hello-line" /></p>
        <h1>A curious<br />mind. A creative<br /><span className="hero-word">perspective<span className="lime-period">.</span></span></h1>
        <p className="hero-description">{profile.introduction}</p>
        <div className="hero-buttons flex flex-wrap items-center gap-3">
          <a href="#insights" className="button button-primary">Explore my thinking<span className="button-arrow"><ArrowUpRight size={20} aria-hidden="true" /></span></a>
          <a href="#contact" className="button button-outline">Get in touch<ArrowUpRight size={18} aria-hidden="true" /></a>
        </div>
      </motion.div>
      <motion.div className="hero-art" initial={reduced ? false : {opacity:0,scale:0.95}} animate={{opacity:1,scale:1}} transition={{duration:1,delay:0.12}}>
        <div className="orbit-ring" aria-hidden="true" />
        <div className="orb orb-lime" aria-hidden="true" /><div className="orb orb-blue" aria-hidden="true" /><div className="orb orb-glass" aria-hidden="true" />
        <div className="portrait-frame"><img src={asset('images/profile/portrait.webp')} alt="Adarsha Vimukthikani" width="1000" height="1250" fetchPriority="high" /></div>
        <div className="portrait-note"><span className="note-icon"><Spark /></span><div>Rooted in business.<br /><strong>Drawn to possibility.</strong></div></div>
        <span className="portrait-side mono">A FRESH PERSPECTIVE, ALWAYS.</span>
        <span className="art-cross" aria-hidden="true">+</span>
      </motion.div>
    </div>
    <div className="hero-bottom"><a href="#about" className="scroll-hint"><span className="scroll-circle"><ArrowDown size={16} aria-hidden="true" /></span><span className="mono">A LITTLE MORE ABOUT ME</span></a><div className="hero-bottom-right"><span>Management undergraduate</span><MoveDown size={18} aria-hidden="true" /><span>University of Ruhuna</span></div></div>
  </section>;
}
