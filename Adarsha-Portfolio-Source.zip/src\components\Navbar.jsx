import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, m as motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight, Menu, Moon, Sun, X } from 'lucide-react';
import { navigation } from '../data/navigation';
import { useTheme } from '../context/ThemeContext';
import { Brand } from './Primitives';

export default function Navbar() {
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('');
  const menuButton = useRef(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) if (entry.isIntersecting) setActive(`#${entry.target.id}`);
    }, {rootMargin:'-15% 0px -55% 0px'});
    document.querySelectorAll('main section[id]').forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!open) return;
    const escape = (event) => { if (event.key === 'Escape') { setOpen(false); menuButton.current?.focus(); } };
    const resize = () => { if (window.innerWidth > 900) setOpen(false); };
    document.addEventListener('keydown', escape);
    window.addEventListener('resize', resize);
    return () => { document.removeEventListener('keydown', escape); window.removeEventListener('resize', resize); };
  }, [open]);
  return <header className="site-header">
    <div className="nav-inner shell flex items-center justify-between gap-4">
      <Brand />
      <nav className="desktop-nav" aria-label="Main navigation">{navigation.map((item) => <a key={item.href} href={item.href} className={active === item.href ? 'active' : ''} aria-current={active === item.href ? 'location' : undefined}>{item.label}</a>)}</nav>
      <div className="nav-actions flex items-center gap-3">
        <button type="button" className="theme-toggle icon-button" onClick={toggle} aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`}>
          <AnimatePresence mode="wait" initial={false}><motion.span key={theme} initial={{rotate:reduced ? 0 : -80,opacity:0}} animate={{rotate:0,opacity:1}} exit={{rotate:reduced ? 0 : 80,opacity:0}} transition={{duration:0.18}}>{theme === 'light' ? <Moon size={19} /> : <Sun size={19} />}</motion.span></AnimatePresence>
        </button>
        <a className="nav-contact" href="#contact">Let’s talk <ArrowUpRight size={16} aria-hidden="true" /></a>
        <button ref={menuButton} className="mobile-toggle icon-button" onClick={() => setOpen(!open)} aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="mobile-navigation">{open ? <X size={23} /> : <Menu size={23} />}</button>
      </div>
    </div>
    <AnimatePresence>{open && <motion.nav id="mobile-navigation" aria-label="Mobile navigation" className="mobile-nav" initial={{opacity:0,y:reduced ? 0 : -10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:reduced ? 0 : -10}}>{[...navigation,{href:'#journey',label:'My journey'},{href:'#contact',label:'Get in touch'}].map((item,i) => <a key={item.href} href={item.href} onClick={() => setOpen(false)}><span className="mono">0{i+1}</span>{item.label}<ArrowUpRight size={21} aria-hidden="true" /></a>)}</motion.nav>}</AnimatePresence>
  </header>;
}
