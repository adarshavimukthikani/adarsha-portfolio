import { useState } from 'react';
import { ArrowDown, ArrowUp, ArrowUpRight, Award } from 'lucide-react';
import { certificates, credentialStatus } from '../data/certificates';
import { asset } from '../data/assets';
import { Eyebrow, Reveal } from '../components/Primitives';
import CredentialModal from '../components/CredentialModal';

const categories = ['All', 'Marketing', 'Business', 'Technology'];
export default function Certifications() {
  const [category, setCategory] = useState('All');
  const [expanded, setExpanded] = useState(false);
  const [selected, setSelected] = useState(null);
  const filtered = certificates.filter((item) => category === 'All' || item.category === category);
  const visible = category === 'All' && !expanded ? filtered.slice(0,6) : filtered;
  return <section id="credentials" className="credentials-section section-pad shell">
    <Reveal><Eyebrow number="04">LEARNING, MADE TANGIBLE</Eyebrow><div className="section-heading"><h2>Always a student.<br /><span className="muted-heading">By choice.</span></h2><p>Courses, badges, and new ways of thinking.<br className="desktop-break" /> A collection of the steps I’ve taken so far.</p></div></Reveal>
    <Reveal><div className="filter-row"><div className="filter-controls" role="group" aria-label="Filter credentials by topic">{categories.map((name) => <button key={name} type="button" className={`filter-button ${category === name ? 'selected' : ''}`} aria-pressed={category === name} onClick={() => { setCategory(name); setExpanded(false); }}>{name}{name === 'All' && <span>{certificates.length}</span>}</button>)}</div><span className="credential-counter mono" role="status" aria-live="polite">{filtered.length} LEARNING MILESTONES</span></div></Reveal>
    <div className="credential-grid" id="credential-collection">{visible.map((item) => <button key={item.id} type="button" className={`credential-card ${item.badge ? 'badge-card' : ''}`} data-certificate-id={item.id} onClick={() => setSelected(item)} aria-haspopup="dialog"><div className="credential-image"><img src={asset(`images/certificates/${item.badgeImage || item.image}`)} alt="" width="600" height="420" loading="lazy" /><span className="credential-open"><ArrowUpRight size={20} aria-hidden="true" /></span><span className="credential-type mono">{item.type}</span></div><div className="credential-info"><span className="category-label">{item.issuer}</span><h3>{item.title}</h3><div className="credential-card-bottom"><span>{item.date || item.type}</span>{credentialStatus(item) === 'Expired' ? <span className="expired-label">Expired</span> : <Award size={16} aria-hidden="true" />}</div></div></button>)}</div>
    {category === 'All' && <div className="load-more"><button type="button" className="button button-outline" aria-expanded={expanded} aria-controls="credential-collection" onClick={() => setExpanded(!expanded)}>{expanded ? 'Show selected credentials' : `Explore all ${certificates.length} credentials`}{expanded ? <ArrowUp size={18} /> : <ArrowDown size={18} />}</button></div>}
    {selected && <CredentialModal certificate={selected} onClose={() => setSelected(null)} />}
  </section>;
}
