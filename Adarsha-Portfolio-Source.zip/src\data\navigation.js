export const navigation = [
  { href: '#about', label: 'About' },
  { href: '#expertise', label: 'My toolkit' },
  { href: '#credentials', label: 'Credentials' },
  { href: '#insights', label: 'Insights' },
];
