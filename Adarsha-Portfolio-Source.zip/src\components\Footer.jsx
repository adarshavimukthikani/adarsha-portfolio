import { ArrowUp, ArrowUpRight } from 'lucide-react';
import { Brand } from './Primitives';
import { profile } from '../data/profile';

export default function Footer() {
  return <footer className="site-footer shell"><div className="footer-main"><Brand footer /><p>Business thinking.<br />Creative possibilities.</p><nav aria-label="Footer navigation"><a href="#about">About</a><a href="#credentials">Credentials</a><a href="#insights">Insights</a><a href={profile.linkedin} target="_blank" rel="noopener noreferrer">LinkedIn<ArrowUpRight size={14} aria-hidden="true" /></a><a href={profile.medium} target="_blank" rel="noopener noreferrer">Medium<ArrowUpRight size={14} aria-hidden="true" /></a></nav><a href="#home" className="back-top" aria-label="Back to top"><ArrowUp size={21} aria-hidden="true" /></a></div><div className="footer-bottom"><span>© {new Date().getFullYear()} {profile.name}</span><span>Made with intention. Always evolving.</span><span className="mono">THANK YOU FOR STOPPING BY <span aria-hidden="true">↗</span></span></div></footer>;
}
