# Adarsha Vimukthikani — Business × Creativity

A complete static portfolio built with React, Vite, JavaScript, Tailwind CSS v4, Motion for React, and Lucide. All content is local. No backend, database, authentication, analytics, or runtime API integration.

## Run

Requires Node 22.12+ or Node 24 LTS and npm. From this project folder:

```powershell
npm.cmd ci
npm.cmd run dev
```

Open the Local URL printed by Vite, normally `http://127.0.0.1:5173`. On macOS/Linux use `npm` instead of `npm.cmd`. The `.cmd` form avoids PowerShell script-execution-policy issues on Windows.

```powershell
npm.cmd run check
npm.cmd run build
npm.cmd run preview
```

The deployment-ready output is **dist/**. Preview normally runs at `http://127.0.0.1:4173`. Do not open `dist/index.html` with the `file:` protocol; serve it over HTTP.

Verified on October 17, 2026: the production build and content checks pass. Browser checks pass at five widths in both themes, with no console errors, broken local images, invalid internal anchors, or automated WCAG A/AA violations in the scanned pages and credential dialog.

| Lighthouse profile | Performance | Accessibility | Best practices | SEO |
| --- | --- | --- | --- | --- |
| Desktop | 100 | 100 | 100 | 100 |
| Mobile | 94 | 100 | 100 | 100 |

Both runs reported CLS 0 (below 0.001 before rounding). These are local laboratory scores, not a guarantee of hosted or real-device performance. Details: [Lighthouse summary](docs/lighthouse-summary.json), [browser report](docs/validation-report.json). Visual previews: [light](docs/preview-light.png), [dark](docs/preview-dark.png), [mobile](docs/preview-mobile.png).

## Experience

- Organic portrait hero, dimensional animated CSS orbs, oversized typography, and an original personal wordmark.
- Complete light and dark themes with system detection, persistent preference, cross-tab synchronization, animated toggle, and pre-paint theme initialization.
- About story and an AI-assisted editorial portrait variation based on the supplied photo.
- Three authentic skill groups, education timeline, 13 distinct learning milestones, and six real Medium articles.
- Topic filters, expand/collapse credential collection, native accessible image dialogs with focus trapping, Escape dismissal, and focus restoration.
- Responsive navigation, section indicators, smooth anchors, email/phone links, clipboard action, social links, résumé link, and back-to-top.
- Reduced-motion support, keyboard focus styles, skip link, lazy images, local licensed fonts, WebP imagery, favicon, social image, and Person structured data.
- Motion is used for entrances/reveals; CSS handles lightweight orb motion. GSAP, 3D rendering, routing, and smooth-scroll libraries were unnecessary for this single-page composition.

## Design

Exact supplied identity: **electric blue #1E45FB** and **lime #CDF22B**. Cream #F6F7F2, white, and soft gray-green support the light theme; green-black #10130F and warm ivory support dark mode. Manrope display type, DM Sans body type, and occasional system serif italics create the editorial hierarchy.

The complete palette, source review, content decisions, asset provenance, and portrait-generation prompt are in [docs/design-and-content.md](docs/design-and-content.md).

## Project structure

```text
portfolio/
├── public/
│   ├── favicon.svg
│   ├── fonts/                  # Font license notices
│   └── images/
│       ├── profile/            # Original-photo treatment + illustration
│       ├── certificates/       # 13 credentials + companion Google badge
│       ├── articles/           # Six supplied covers
│       └── social-preview.webp
├── src/
│   ├── components/             # Navbar, footer, motion helpers, dialog
│   ├── context/ThemeContext.jsx
│   ├── data/                   # Profile, navigation, skills, credentials, articles
│   ├── sections/               # Seven complete page sections
│   ├── styles/index.css        # Semantic tokens, Tailwind, responsive styles
│   ├── App.jsx
│   └── main.jsx
├── scripts/                    # Content, asset, social image, browser checks
├── docs/                       # Source and verification record
├── index.html
├── vite.config.js
├── package.json
├── package-lock.json
└── .gitignore
```

All original `old details`, `reference web`, and `Resources` folders remain untouched outside this project. Optimized assets are already included; building does not require those source folders or access to an image generator.

## Integrated badges and certificates

| Credential | Issuer | Date shown in supplied material |
| --- | --- | --- |
| Social Media Marketing — Level 4 badge | Chartered Institute of Marketing | Not supplied |
| Responsible Marketing — Level 4 badge | Chartered Institute of Marketing | Not supplied |
| Google Ads Display certificate and badge | Google | Sep 21, 2025; expired Sep 21, 2026 |
| Digital Marketing Professional Certificate | Content Marketing Institute / LinkedIn Learning | Apr 23, 2025 |
| Social Media Marketing Professional Certificate | Hootsuite / LinkedIn Learning | Apr 18, 2025 |
| Fundamentals in Digital Marketing | Asia Pacific Institute of Digital Marketing | Not supplied |
| Google Analytics 4 (GA4) Essential Training | LinkedIn Learning | Apr 2, 2025 |
| Cybersecurity for Businesses — The Fundamental Edition | EC-Council Continuing Education | Jun 2, 2025 |
| Foundations of Project Management | University of Moratuwa, CODL | Not supplied |
| Digital Marketing Foundations | LinkedIn Learning | Mar 14, 2025 |
| Email Marketing | Great Learning Academy | Oct 2024 |
| Data Visualization With Power BI | Great Learning Academy | Oct 2024 |
| SEO Strategies | Great Learning Academy | Oct 2024 |

The Google badge and certificate are one credential; the duplicate project-management document is displayed once. Course completion/participation is distinguished from certification.

## Integrated Medium articles

1. [Nike Just Do It Campaign](https://medium.com/@adarshavimukthikani/nike-just-do-it-campaign-e9cb2a7a41c7)
2. [McDonald’s i’m lovin’ it Campaign](https://medium.com/@adarshavimukthikani/mcdonalds-i-m-lovin-it-campaign-02b575398dbb)
3. [The Dove Real Beauty Campaign](https://medium.com/@adarshavimukthikani/the-dove-real-beauty-campaign-01e302dd3f44)
4. [The Starbucks Red Cup Campaign](https://medium.com/@adarshavimukthikani/the-starbucks-red-cup-campaign-830d80df2e9b)
5. [Shot On iPhone Campaign](https://medium.com/@adarshavimukthikani/shot-on-iphone-campaign-72e1c6294799) — Sinhala
6. [Coca-Cola Share a coke Campaign](https://medium.com/@adarshavimukthikani/coca-cola-share-a-coke-campaign-4616d66abfd7) — Sinhala

All six canonical destinations match both the supplied shortened URLs and the author’s public RSS feed. Medium blocks direct automated page checks here; the URLs were not invented. See `docs/external-link-check.json` for raw checks and `docs/design-and-content.md` for the verification limits.

## Change content

Edit the relevant JavaScript file under `src/data/`. Replace imagery in `public/images/`, retaining its filename or updating the corresponding data entry. Theme tokens and breakpoints are in `src/styles/index.css`. No content needs a remote service. Do not change expiry dates unless a renewed credential is supplied.

## Deploy

**Vercel:** import the repository, set Root Directory to `portfolio` if the repository contains the parent resource folders, select Vite, use `npm run build`, and output `dist`.

**Netlify:** set Base Directory to `portfolio` when applicable, Build Command `npm run build`, Publish Directory `dist`. You can also drag the built `dist` folder onto Netlify’s manual deployment interface.

**GitHub Pages:** deploy only the contents of `dist` using GitHub Actions or a Pages deployment branch. Vite uses `base: './'`, so assets work at either a domain root or a repository subpath. This is a single page with anchor navigation; no SPA rewrite or router fallback is required.

For correct absolute social-sharing metadata and a canonical URL, set the optional **build-time** environment variable `VITE_SITE_URL` to the actual final URL, including a repository subpath when applicable. No invented deployment URL is included.

```powershell
$env:VITE_SITE_URL = 'https://your-actual-domain.example'
npm.cmd run build
```

Replace that documentation example with your genuine URL. Hosting dashboards can set the same environment variable. Rebuild after changing it. The site runs without this variable; absolute canonical/OG URL tags are emitted only when a real domain is supplied.

## Verification

`npm run check` verifies local assets, uniqueness, and article URLs against the saved author feed. `npm run test:browser` starts and stops its own production preview and runs headless Chromium checks at 1440, 1024, 768, 390, and 320px in both themes. It checks images, anchors, overflow, themes, credentials, native modal keyboard behavior, clipboard, mobile navigation, and automated WCAG A/AA rules. Screenshots and a JSON report are written to ignored `test-results/`.

The browser script uses installed Chrome or Edge on Windows. On other systems install the Playwright browser once with `npx playwright install chromium`, or set `BROWSER_PATH` to an installed Chromium executable. Automated accessibility tests supplement visual/keyboard review; they are not a formal accessibility certification.

Browser validation uses port 4174 by default; set `PORTFOLIO_TEST_PORT` to use another free port. Optional `scripts/prepare-assets.mjs` re-optimizes the source assets from the sibling Resources/old details folders and the included editorial source PNG. This preparation is already complete and is not needed to run, build, or deploy. The full image-generation prompt and the built-in tool provenance are documented in `docs/design-and-content.md`.

## Content limitations

No job history, client projects, testimonials, separate WhatsApp photo, or local résumé PDF was supplied. These were omitted rather than fabricated. Missing credential dates are omitted. The name follows the documents (**Adarsha Vimukthikani**). The hero uses the actual supplied photo; only the About illustration is AI-assisted. The complete site is local and ready for static deployment; no hosting account was changed or deployment performed.
