import { Megaphone, Palette, Shapes, ArrowUpRight } from 'lucide-react';
import { skills } from '../data/skills';
import { Eyebrow, Reveal } from '../components/Primitives';
const icons = {marketing:Megaphone,design:Palette,business:Shapes};

export default function Skills() {
  return <section id="expertise" className="expertise-section section-pad shell">
    <Reveal><Eyebrow number="02">MY GROWING TOOLKIT</Eyebrow><div className="section-heading"><h2>Different skills.<br /><span className="muted-heading">Connected thinking.</span></h2><p>A blend of business foundations,<br className="desktop-break" /> creative tools, and a willingness to learn.</p></div></Reveal>
    <div className="skills-grid">{skills.map((skill,i) => { const Icon = icons[skill.icon]; return <Reveal key={skill.id} delay={i*0.08} className={`skill-card skill-${skill.icon}`}><div className="skill-top"><span className="skill-icon"><Icon size={28} strokeWidth={1.5} aria-hidden="true" /></span><span className="mono">/{skill.id}</span></div><h3>{skill.title}</h3><p>{skill.description}</p><div className="skill-tags">{skill.tags.map(tag => <span key={tag}>{tag}</span>)}</div></Reveal>; })}</div>
  </section>;
}
