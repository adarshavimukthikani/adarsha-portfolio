import { access, readFile, stat } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { certificates } from '../src/data/certificates.js';
import { articles } from '../src/data/articles.js';
import { profile } from '../src/data/profile.js';

for (const item of certificates) {
  await access(`public/images/certificates/${item.image}`);
  if (item.badgeImage) await access(`public/images/certificates/${item.badgeImage}`);
  assert.ok(item.title && item.issuer && item.category);
}
const feed = await readFile('docs/medium-feed.xml','utf8');
for (const item of articles) {
  await access(`public/images/articles/${item.image}`);
  assert.ok(feed.includes(item.url), `Article URL missing from the author’s feed: ${item.title}`);
  assert.equal(new URL(item.url).hostname, 'medium.com');
  assert.ok(!item.url.endsWith('#'));
}
assert.equal(new Set(certificates.map(x=>x.id)).size, certificates.length);
assert.equal(new Set(articles.map(x=>x.id)).size, articles.length);
assert.equal(profile.email, 'adarshavimukthikani@gmail.com');
for (const file of ['portrait.webp','editorial.webp']) await access(`public/images/profile/${file}`);
await access('public/images/social-preview.webp');
assert.ok((await stat('public/images/profile/portrait.webp')).size < 200000);
console.log(`Content verified: ${certificates.length} distinct credentials, ${articles.length} article URLs matched to the public author feed, and all referenced local imagery.`);
