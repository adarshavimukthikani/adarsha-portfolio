import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { asset } from '../data/assets';
import { profile } from '../data/profile';
import { ArrowLink, Eyebrow, Reveal, Spark } from '../components/Primitives';

export default function About() {
  return <section id="about" className="about-section section-pad">
    <div className="shell"><Reveal><Eyebrow number="01">THE PERSON BEHIND THE PERSPECTIVE</Eyebrow></Reveal>
      <div className="about-grid">
        <Reveal className="about-art"><div className="editorial-photo"><img src={asset('images/profile/editorial.webp')} alt="An editorial illustration of Adarsha, based on her original portrait" width="880" height="1100" loading="lazy" /></div><div className="about-sticker"><Spark /><span>Stay curious.<br />Keep creating.</span></div><span className="image-caption mono">A DIFFERENT LENS. THE SAME ME.</span></Reveal>
        <div className="about-copy"><Reveal><h2>A business mind.<br />A <span className="serif-word">creative</span> heart.</h2><p className="section-intro">I’m interested in what happens when thoughtful strategy meets a good idea.</p></Reveal>
          {profile.about.map((p,i) => <Reveal key={p} delay={i*0.08}><p className="body-copy">{p}</p></Reveal>)}
          <Reveal><div className="about-values"><span><span className="tiny-dot" />Curiosity first</span><span><span className="tiny-dot" />Clarity always</span><span><span className="tiny-dot" />Better together</span></div><ArrowLink href={profile.resume} external>View my résumé</ArrowLink></Reveal>
        </div>
      </div>
      <Reveal><div className="perspective-strip"><ArrowDownRight className="strip-arrow" size={46} aria-hidden="true" /><p>Good ideas begin with<br /><span>better questions.</span></p><span className="mono">MY APPROACH<br />TO LEARNING & CREATING</span><Spark className="strip-spark" /></div></Reveal>
    </div>
  </section>;
}
