import { GraduationCap, MoveUpRight } from 'lucide-react';
import { education } from '../data/profile';
import { Eyebrow, Reveal } from '../components/Primitives';

export default function Experience() {
  return <section id="journey" className="journey-section section-pad"><div className="shell journey-grid"><Reveal><Eyebrow number="03">THE JOURNEY SO FAR</Eyebrow><h2>Building a<br />foundation.<br /><span className="muted-heading">Finding my voice.</span></h2><p className="journey-intro">My path brings formal study together with independent learning and a growing interest in the creative side of business.</p><div className="journey-symbol" aria-hidden="true"><GraduationCap size={56} strokeWidth={1.2} /><span>Learning is<br />a lifelong practice.</span></div></Reveal>
    <div className="timeline">{education.map((item,i) => <Reveal className="timeline-item" key={item.year} delay={i*0.1}><span className="timeline-dot" /><div className="timeline-meta mono"><span>{item.year}</span><span>{item.label}</span></div><h3>{item.title}</h3><p className="timeline-org">{item.organization}</p><p className="body-copy">{item.description}</p></Reveal>)}<Reveal className="timeline-note"><MoveUpRight size={22} aria-hidden="true" /><p>And in between?<br /><strong>A lot of curiosity, courses, and creating.</strong></p></Reveal></div>
  </div></section>;
}
