# Design and content record

## Reference review

Both files in `../reference web/` were opened and inspected before implementation. No reference website URLs, source files, alternate screenshots, or mobile layouts were supplied.

`3e32cc9dd9868f7074987dcecc3b6b1a.jpg` shows an Aeline agency landing page: a broad blue hero, centered light-weight display typography, pale blue secondary type, small spaced navigation, lime pill buttons, floating curved cards, cloud imagery, generous white spacing, and rounded asymmetric information blocks. Its hierarchy relies on one dominant visual, restrained metadata, and clear contrast. It is a static screenshot, so actual animations, mobile behavior, keyboard interactions, button transitions, and scrolling could not be inspected.

`e023596561453727c2ea57ef66896aae.jpg` is the preferred palette: the swatches explicitly identify **#CDF22B** and **#1E45FB**. The image pairs bold black rounded typography with large lime and blue geometric forms, rounded corners, and white space.

The resulting portfolio uses an original split hero, a real portrait in an organic frame, dimensional CSS orbs, soft cream editorial surfaces, oversized Manrope typography, and lime accents. The floating visual rhythm, generous spacing, pill controls, and blue/lime identity carry through the reference influence. Clouds, template-specific layouts, logos, sample statistics, client marks, and testimonials were not reused.

## Semantic palette

| Token | Light | Dark |
| --- | --- | --- |
| Primary | #1E45FB | #1E45FB |
| Secondary | #152BB1 | #8295FF |
| Accent | #CDF22B | #CDF22B |
| Background | #F6F7F2 | #10130F |
| Surface | #FFFFFF | #1B2019 |
| Alternate surface | #EEEFE9 | #171B15 |
| Text | #1C211D | #F1F3E9 |
| Muted text | #656B61 | #A5AE9E |
| Border | #D9DDD2 | #343B2F |
| Hover | #E9EDDF | #283024 |
| Blue text | #1E45FB | #9AAAFF |
| Gradient | #1E45FB → #536CFF | #1E45FB → #4D62F0 |

These CSS custom properties are mapped to Tailwind v4 semantic tokens in `src/styles/index.css`. Dark mode uses green-black and warm ivory to retain the character of the cream/lime light theme. Blue backgrounds retain white text; blue text has a lighter accessible dark-mode variant. Font files are local, variable, SIL Open Font License Manrope and DM Sans; license copies are in `public/fonts/`. Georgia supplies occasional system serif italics.

## Source of truth and editorial choices

- `../old details/index.html` supplies the name, study programme, university, education years, A/L results, skills, résumé link, phone, email, LinkedIn, and Medium profile.
- Source documents and certificates consistently use **Adarsha Vimukthikani**, which is used throughout. The spelling in the initial prompt differs.
- The source describes a first-year student in 2024. The site retains the undergraduate programme and its 2024 timeline entry without claiming a current year of study or a graduation date.
- No employment, client work, awards, testimonials, or project outcomes were supplied. The site therefore presents education, learning milestones, and genuine published campaign analyses.
- All image assets under Resources and the older portfolio were inspected. Older decorative stock illustration and Photoshop logo were not needed in the new identity. The older project-management image is a higher-resolution duplicate of the Resources certificate and is displayed once.
- No separately named “all details,” WhatsApp image, CV PDF, or additional personal photograph was present. `old details` provides the requested previous-portfolio information; the supplied public résumé URL remains available.
- Missing badge issue dates are omitted. No guessed credential IDs or URLs are generated. The Moratuwa verification link is printed on the actual certificate; users must supply their verification code there.
- Google Ads Display lists issue date September 21, 2025 and expiry September 21, 2026. Its status is calculated from that expiry and it is not represented as currently valid after expiry. The Google badge and certificate belong to one credential.
- EC-Council is accurately labeled as course completion, following the qualification printed on its document.

## Articles and link verification

All six shortened links in `../Resources/New Text Document.txt` were retrieved. Each returned a LinkedIn external-link page identifying the corresponding canonical Medium URL. All six also appear in the public author feed saved as `docs/medium-feed.xml`. Titles and cover subjects match the six local supplied images. English summaries were derived from those actual articles. The iPhone and Coca-Cola articles are labeled Sinhala based on their body content. No publication dates or reading times were invented.

The direct Medium pages reject automated HTTP requests with 403 in this environment; LinkedIn returns 999. Those responses do not establish that the user’s genuine URLs are broken. The public Medium feed and short-link destinations verify the article identity, but manual publisher-page access cannot be guaranteed from automated checks. The supplied Google Drive résumé and University of Moratuwa verification page returned HTTP 200. Raw request statuses are recorded in `external-link-check.json`.

## Portrait treatment

The hero uses the original supplied photograph, optimized to WebP, with a CSS crop, gentle saturation treatment, organic masking, layered orbs, and a translucent annotation. Its facial identity is unchanged. The About section uses an AI-assisted editorial illustration, generated with the built-in image generation tool from that same photo and visually inspected. It is described as an illustration in its alt text and is used once.

Optimized deliverable: `public/images/profile/editorial.webp`.

Generation prompt:

> Use case: style-transfer, identity-preserve. Edit target: supplied portrait of Adarsha Vimukthikani. Asset: a sophisticated semi-illustrated editorial portrait for her professional business and digital marketing portfolio. Preserve her exact recognizable facial identity, facial proportions, skin tone, long black hair, expression, pose, and dark navy top. Render with understated fine gouache-like brushwork, softly modeled dimensional light, subtle photographic detail in the eyes, polished modern editorial illustration, not cartoon or avatar. Chest-up vertical 4:5 framing, complete hair silhouette with breathing room, elegant warm off-white backdrop with an abstract electric-blue #1E45FB oval and a small pale lime #CDF22B circle behind her. Refined professional mood. No text, logos, extra people, accessories, makeup changes, exaggerated facial features, or change of identity.

Image provenance for every optimized asset is in `asset-provenance.json`. Original user files remain unchanged.
