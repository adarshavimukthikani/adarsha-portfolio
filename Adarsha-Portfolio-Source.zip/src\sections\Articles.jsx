import { ArrowUpRight, BookOpen } from 'lucide-react';
import { articles } from '../data/articles';
import { profile } from '../data/profile';
import { asset } from '../data/assets';
import { ArrowLink, Eyebrow, Reveal } from '../components/Primitives';

export default function Articles() {
  return <section id="insights" className="insights-section section-pad"><div className="shell">
    <Reveal><Eyebrow number="05">NOTES FROM A CURIOUS MIND</Eyebrow><div className="section-heading"><h2>Big brands.<br /><span className="serif-word">Interesting</span> stories.</h2><div><p>I unpack the campaigns that make us<br className="desktop-break" /> feel, connect, and remember.</p><ArrowLink href={profile.medium} external>Find me on Medium</ArrowLink></div></div></Reveal>
    <div className="articles-grid">{articles.map((article,i) => <Reveal className="article-wrap" key={article.id} delay={(i%3)*0.07}><article className="article-card"><a href={article.url} className="article-image-link" target="_blank" rel="noopener noreferrer" aria-label={`Read ${article.title} on Medium`}><img src={asset(`images/articles/${article.image}`)} alt={`${article.title} article cover`} width="685" height="450" loading="lazy" /><span className="article-image-arrow"><ArrowUpRight size={24} aria-hidden="true" /></span></a><div className="article-meta"><span className="category-label">{article.category}</span><span>{article.language}</span></div><h3><a href={article.url} target="_blank" rel="noopener noreferrer">{article.title}</a></h3><p>{article.description}</p><a className="article-read" href={article.url} target="_blank" rel="noopener noreferrer">Read the story<ArrowUpRight size={17} aria-hidden="true" /></a></article></Reveal>)}</div>
    <Reveal><div className="insights-footnote"><BookOpen size={19} aria-hidden="true" /><p>Independent campaign analyses, written and published on Medium.</p></div></Reveal>
  </div></section>;
}
