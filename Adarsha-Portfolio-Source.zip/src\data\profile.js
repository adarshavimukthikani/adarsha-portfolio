export const profile = {
  name: 'Adarsha Vimukthikani',
  firstName: 'Adarsha',
  title: 'Management undergraduate & creative thinker',
  email: 'adarshavimukthikani@gmail.com',
  phone: '+94 76 028 7547',
  phoneHref: 'tel:+94760287547',
  linkedin: 'https://www.linkedin.com/in/adarsha-vimukthikani-024776333/',
  medium: 'https://medium.com/@adarshavimukthikani',
  resume: 'https://drive.google.com/file/d/1xh2dmM9Qj4VJxjRExh7JjqXf8RADwyw4/view?usp=sharing',
  introduction: 'A management undergraduate exploring the space between business, digital marketing, and visual storytelling. Learning with intention. Creating with curiosity.',
  about: [
    'I’m Adarsha, a BBA Management undergraduate at the University of Ruhuna. My studies in management and finance give me a commercial foundation; design and digital marketing give me a creative outlet.',
    'I enjoy understanding why an idea connects with people, then finding a clear, thoughtful way to communicate it. From creating visuals in Canva and Photoshop to unpacking brand campaigns on Medium, I’m building my perspective one project, course, and conversation at a time.',
  ],
};

export const education = [
  { year: '2024', title: 'BBA Management', organization: 'University of Ruhuna', label: 'Undergraduate studies', description: 'Building a foundation in management, finance, business administration, accounting, and project management.' },
  { year: '2022', title: 'GCE Advanced Level', organization: 'Commerce stream', label: '2 A grades · 1 B grade', description: 'A grounding in commerce that sparked my interest in how businesses work and grow.' },
];
