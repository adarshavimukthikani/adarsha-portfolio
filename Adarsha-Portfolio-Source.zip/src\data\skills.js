export const skills = [
  { id: '01', icon: 'marketing', title: 'Digital marketing', description: 'Exploring how brands reach people, build trust, and turn attention into connection.', tags: ['Social media marketing', 'Facebook & Instagram', 'Email marketing', 'SEO foundations'] },
  { id: '02', icon: 'design', title: 'Visual storytelling', description: 'Turning ideas into considered visuals, from a social post to a more memorable message.', tags: ['Canva', 'Photoshop fundamentals', 'Social content', 'Flyers & thumbnails'] },
  { id: '03', icon: 'business', title: 'Business thinking', description: 'Bringing structure, curiosity, and a collaborative mindset to the problem in front of me.', tags: ['Business administration', 'Project management', 'Critical thinking', 'Teamwork'] },
];
