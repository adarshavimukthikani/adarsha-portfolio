import { chromium, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { mkdir, writeFile, access } from 'node:fs/promises';
import { spawn } from 'node:child_process';

const port = process.env.PORTFOLIO_TEST_PORT || '4174';
const base = `http://127.0.0.1:${port}`;
const artifacts = 'test-results';
await mkdir(artifacts,{recursive:true});
const server = spawn(process.execPath,['node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port',port,'--strictPort'],{windowsHide:true,stdio:'pipe'});
let serverOutput=''; server.stdout.on('data',d=>serverOutput+=d); server.stderr.on('data',d=>serverOutput+=d);
let browser;
const report = {viewports:[],checks:[],errors:[],accessibility:[]};
try {
  for (let i=0;i<50;i++) { try { const response=await fetch(base); if(response.ok) break; } catch {} await new Promise(r=>setTimeout(r,150)); }
  const candidates = [process.env.BROWSER_PATH,'C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].filter(Boolean);
  let executablePath;
  for (const file of candidates) { try { await access(file);executablePath=file;break; } catch {} }
  browser = await chromium.launch({headless:true,...(executablePath?{executablePath}:{})});
  for (const width of [1440,1024,768,390,320]) {
    for (const theme of ['light','dark']) {
      const context = await browser.newContext({viewport:{width,height:width<700?844:1000},colorScheme:theme,reducedMotion:'reduce',deviceScaleFactor:1});
      const page = await context.newPage();
      page.on('pageerror',error=>report.errors.push(error.message));
      page.on('console',msg=>{if(msg.type()==='error') report.errors.push(msg.text());});
      page.on('response',response=>{if(response.url().startsWith(base)&&response.status()>=400) report.errors.push(`${response.status()} ${response.url()}`);});
      await page.goto(base,{waitUntil:'networkidle'});
      await page.evaluate(()=>document.fonts.ready);
      await expect(page.locator('h1')).toBeVisible();
      await expect(page.locator('html')).toHaveAttribute('data-theme',theme);
      const geometry = await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth,overflow:[...document.querySelectorAll('body *')].filter(el=>{const r=el.getBoundingClientRect();return r.width&&r.right>innerWidth+1&&getComputedStyle(el).position!=='fixed';}).map(el=>({tag:el.tagName,class:el.className.baseVal??el.className,right:el.getBoundingClientRect().right})).slice(0,8)}));
      report.viewports.push({width,theme,...geometry});
      if (geometry.document > width) await page.screenshot({path:`${artifacts}/overflow-${width}-${theme}.png`,fullPage:true,animations:'disabled'});
      expect(geometry.document,`Horizontal overflow at ${width}px ${theme}`).toBeLessThanOrEqual(width);
      const badAnchors = await page.locator('a').evaluateAll(links=>links.filter(a=>!a.getAttribute('href')||a.getAttribute('href')==='#'||(a.hash&&a.origin===location.origin&&!document.getElementById(a.hash.slice(1)))).map(a=>a.outerHTML));
      expect(badAnchors).toEqual([]);
      await page.evaluate(async()=>{for(const img of document.images){img.loading='eager';} await Promise.all([...document.images].map(img=>img.decode().catch(()=>{})));});
      const brokenImages=await page.locator('img').evaluateAll(images=>images.filter(i=>!i.complete||!i.naturalWidth).map(i=>i.src));
      expect(brokenImages).toEqual([]);
      if ([1440,390,320].includes(width)) await page.screenshot({path:`${artifacts}/${width}-${theme}.png`,fullPage:true,animations:'disabled'});
      if ([1440,390].includes(width)) {
        const results=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();
        report.accessibility.push({width,theme,violations:results.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))});
      }
      await context.close();
    }
  }
  const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:'light',reducedMotion:'reduce',permissions:['clipboard-read','clipboard-write']});
  const page=await context.newPage();
  await page.goto(base,{waitUntil:'networkidle'});
  await page.getByRole('button',{name:'Switch to dark theme'}).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
  await page.reload();await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
  await page.getByRole('button',{name:'Switch to light theme'}).click();
  report.checks.push('Theme toggle persists across reload and both theme states render.');
  await expect(page.locator('.credential-card')).toHaveCount(6);
  await page.getByRole('button',{name:'Explore all 13 credentials'}).click();
  await expect(page.locator('.credential-card')).toHaveCount(13);
  for(const [name,count] of [['Technology',3],['Business',1],['Marketing',9]]) {await page.getByRole('button',{name,exact:true}).click();await expect(page.locator('.credential-card')).toHaveCount(count);}
  await page.getByRole('button',{name:/^All\s*13$/}).click();
  const googleCard=page.locator('[data-certificate-id="google-display"]');
  await googleCard.click();await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByRole('dialog').getByRole('heading',{name:'Google Ads Display',exact:true})).toBeVisible();
  await expect(page.getByText('Expired: September 21, 2026',{exact:true})).toBeVisible();
  await page.screenshot({path:`${artifacts}/credential-modal.png`,animations:'disabled'});
  const modalAxe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa']).analyze();
  report.accessibility.push({context:'Credential modal',violations:modalAxe.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))});
  for(let i=0;i<8;i++) {await page.keyboard.press('Tab');expect(await page.evaluate(()=>document.querySelector('dialog').contains(document.activeElement))).toBe(true);}
  await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);await expect(googleCard).toBeFocused();
  report.checks.push('All credential filters, expand/collapse, native modal, keyboard focus trap, Escape close, and focus restoration.');
  await page.getByRole('button',{name:'Copy email address',exact:true}).click();
  await expect(page.getByText('Email address copied.',{exact:true})).toBeVisible();
  expect(await page.evaluate(()=>navigator.clipboard.readText())).toBe('adarshavimukthikani@gmail.com');
  report.checks.push('Email clipboard action and accessible success feedback.');
  await page.setViewportSize({width:390,height:844});
  await page.getByRole('button',{name:'Open menu'}).click();await expect(page.getByRole('navigation',{name:'Mobile navigation'})).toBeVisible();
  await page.screenshot({path:`${artifacts}/mobile-menu.png`,animations:'disabled'});
  await page.keyboard.press('Escape');await expect(page.getByRole('navigation',{name:'Mobile navigation'})).toHaveCount(0);
  await page.getByRole('button',{name:'Open menu'}).click();await page.getByRole('navigation',{name:'Mobile navigation'}).getByRole('link',{name:/My toolkit/}).click();await expect(page.getByRole('navigation',{name:'Mobile navigation'})).toHaveCount(0);expect(new URL(page.url()).hash).toBe('#expertise');
  report.checks.push('Mobile menu opening, Escape dismissal, and anchor navigation.');
  const darkContext=await browser.newContext({colorScheme:'dark',reducedMotion:'reduce'});const darkPage=await darkContext.newPage();await darkPage.goto(base);await expect(darkPage.locator('html')).toHaveAttribute('data-theme','dark');await darkPage.emulateMedia({colorScheme:'light'});await expect(darkPage.locator('html')).toHaveAttribute('data-theme','light');await darkContext.close();
  report.checks.push('System theme detection and live system preference changes.');
  const motionContext=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:'light',reducedMotion:'no-preference'});const motionPage=await motionContext.newPage();await motionPage.goto(base,{waitUntil:'networkidle'});await expect(motionPage.locator('.hero-copy')).toHaveCSS('opacity','1');await expect(motionPage.locator('.hero-art')).toHaveCSS('opacity','1');await motionPage.screenshot({path:`${artifacts}/hero-motion.png`,animations:'disabled'});await motionPage.locator('#about').scrollIntoViewIfNeeded();await expect(motionPage.locator('.about-copy > div').first()).toHaveCSS('opacity','1');await motionContext.close();report.checks.push('Normal-motion hero and scroll reveal complete successfully; reduced-motion checked across all viewport captures.');
  await context.close();
  await writeFile(`${artifacts}/report.json`,JSON.stringify(report,null,2));
  expect(report.errors,'Browser console errors or failed local requests').toEqual([]);
  const violations=report.accessibility.flatMap(result=>result.violations);
  expect(violations,'Automated accessibility violations; see report.json').toEqual([]);
  console.log(JSON.stringify({viewports:report.viewports.length,checks:report.checks,consoleErrors:report.errors.length,accessibilityViolations:violations.length,screenshots:artifacts},null,2));
} catch(error) {
  await writeFile(`${artifacts}/report.json`,JSON.stringify({...report,failure:String(error),serverOutput},null,2));
  console.error(error);process.exitCode=1;
} finally { if(browser) await browser.close();server.kill(); }
