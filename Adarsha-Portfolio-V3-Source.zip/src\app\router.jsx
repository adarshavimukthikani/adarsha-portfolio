import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, m as motion, useReducedMotion } from 'motion/react';
import Home from '../pages/Home';
import About from '../pages/About';
import Work from '../pages/Work';
import Skills from '../pages/Skills';
import Education from '../pages/Education';
import Credentials from '../pages/Credentials';
import Articles from '../pages/Articles';
import Contact from '../pages/Contact';
import NotFound from '../pages/NotFound';

export default function AppRoutes() {
  const location = useLocation();
  const reduced = useReducedMotion();
  return <AnimatePresence mode="wait" initial={false}><motion.div key={location.pathname} className="route-view" initial={reduced ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: reduced ? 0 : -8 }} transition={{ duration: reduced ? 0 : 0.2 }}>
    <Routes location={location}>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/work" element={<Work />} />
      <Route path="/skills" element={<Skills />} />
      <Route path="/education" element={<Education />} />
      <Route path="/credentials" element={<Credentials />} />
      <Route path="/articles" element={<Articles />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  </motion.div></AnimatePresence>;
}
