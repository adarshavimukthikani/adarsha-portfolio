# Adarsha Vimukthikani | V3 portfolio

A static, multi-page React portfolio with eight distinct pages. React Router uses the browser History API, so every navigation destination has its own URL. Built with React, Vite, JavaScript/JSX, Tailwind CSS, and Motion for React. No backend, database, authentication, or runtime API is required.

## Run

From this folder with Node 22.12+ or Node 24 LTS:

```powershell
npm.cmd ci
npm.cmd run dev
```

Open the Local URL printed by Vite, normally `http://127.0.0.1:5173`. On macOS/Linux use `npm` instead of `npm.cmd`.

```powershell
npm.cmd run check
npm.cmd run build
npm.cmd run test:browser
npm.cmd run preview
```

The deployment output is `dist/`. Serve it over HTTP, rather than opening `index.html` with the file protocol. `node scripts/serve-static.mjs` previews the production bundle and its SPA fallback at `http://127.0.0.1:4173`.

## Pages

| URL | Content |
| --- | --- |
| `/` | Portrait introduction, moving type strip, selected previews, and links to the full pages |
| `/about` | Personal story, separate editorial portrait, and approach to learning |
| `/work` | Public Relations Coordinator, Circle of Marketing, University of Ruhuna |
| `/skills` | Distinct branding, strategy, communication, and management compositions; separate software/platform area |
| `/education` | University identity and campus, prominent CIM Level 4 studies, expandable curriculum overview, earlier education |
| `/credentials` | Separate badges, professional certificates, and additional learning; filters and full-image dialogs |
| `/articles` | One featured Medium article and five additional genuine articles |
| `/contact` | Real email, clipboard, phone, LinkedIn, and Medium actions |
| Other URLs | Dedicated 404 page with working navigation |

Shared navigation uses `NavLink` active states. Route changes reset scroll and retain theme preference. The home page does not render the full dedicated-page collections. Reduced-motion settings stop the marquee and remove route/reveal movement.

## Hosting and direct-route refresh

Netlify is the documented static hosting target: `netlify.toml` sets the build/publish directory and an HTTP 200 fallback to `index.html`. The same fallback is included in `public/_redirects` for Netlify/Cloudflare Pages. `vercel.json` supplies a Vercel rewrite, and `public/.htaccess` supplies an Apache rewrite when mod_rewrite is available. Deploy the site at the domain root. A host must honor its fallback file; uploading only files to an unconfigured file server will not provide direct-route refreshes.

The browser suite serves the built output using the actual `dist/_redirects` rule and checks direct URLs, refresh, history, all navigation destinations, active links, scroll reset, theme persistence, responsive widths, real image decoding, credential interactions, email actions, and accessibility. This verifies the production bundle and the fallback contract locally; it is not a claim that an external host has been deployed.

Latest acceptance results and all desktop/mobile screenshots are generated in `test-results/v3/`. [Design/content audit](docs/design-and-content.md), [official institutional research](docs/v3-official-sources.md), [article source check](docs/v3-article-links.json), and [portrait edit prompt](docs/v3-portrait.md) document the inputs and their limits. Old Lighthouse numbers are not reused for this redesign.

Validated October 18, 2026: production build and content checks pass; 80 route/viewport/theme checks and the navigation/interaction checks pass, with zero console errors and zero automated WCAG A/AA violations in the scanned routes and credential dialog. All eight routes were captured and visually reviewed on desktop and mobile in both themes. Browse the [screenshot gallery](docs/v3-preview-gallery.html) or [acceptance report](docs/v3-validation-report.json). The connected in-app browser was unavailable; automated Chromium supplied the browser checks and screenshots.

## Identity and assets

The original `adarsha.` wordmark, Manrope and DM Sans typography, cream/green-black themes, and lime accent are preserved. Powder blue `#C2D5E2` replaces the electric-blue UI accents. Official logos retain their original brand colours. All imagery and fonts are local.

The role is supplied by the owner; the official Circle of Marketing page supplies organizational context, not independent appointment verification. CIM is shown as **in progress**. Available modules are labelled **Curriculum Overview**, without inventing the remaining selections. The supplied Responsible Marketing and Social Media Marketing badges appear on Credentials. The Google Ads Display certificate retains its September 21, 2026 expiry.

The [logo catalogue](docs/logo-catalog.html) and [source records](docs/logo-sources.md) include institutional artwork and the Photoshop asset from the original project. Campus photography is credited beside the image. The About image was refined with the built-in image generation tool; the selected [WebP asset](public/images/profile/editorial-v3.webp), original source, and complete prompt are saved locally.

## Recovery

`backups/before-v3-multipage-2026-10-18.zip` preserves the pre-redesign source, assets, scripts, documentation, and package/configuration files. Restore into a separate folder to compare versions. Dependencies can be restored with `npm ci`.
