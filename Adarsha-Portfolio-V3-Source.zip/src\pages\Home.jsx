import { Link } from 'react-router-dom';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { m as motion, useReducedMotion } from 'motion/react';
import { asset } from '../data/assets';
import { profile } from '../data/profile';
import { articles } from '../data/articles';
import BrandLogo from '../components/BrandLogo';
import { Eyebrow, Reveal } from '../components/Primitives';
import { ContactCTA, RouteLink } from '../components/PageUI';
import { BrandBoard } from '../components/CreativeVisuals';

const words = ['Branding', 'Marketing', 'Business', 'Creative thinking', 'Communication'];
export default function Home() {
  const reduced = useReducedMotion();
  const featured = articles[0];
  return <div className="home-page" data-page="home">
    <section className="home-hero shell">
      <div className="hero-topline mono"><span><i className="tiny-dot" />ADARSHA VIMUKTHIKANI</span><span>BUSINESS × CREATIVITY</span></div>
      <div className="hero-grid"><motion.div className="hero-copy" initial={reduced ? false : { opacity: 0, y: 22 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }}><p className="hero-hello">A little curiosity goes a long way.</p><h1>A curious mind.<br />A creative<br /><span className="serif-word">perspective.</span></h1><p className="hero-description">{profile.introduction}</p><div className="hero-buttons"><RouteLink to="/about" button>Meet Adarsha</RouteLink><RouteLink to="/work">Explore my experience</RouteLink></div></motion.div>
        <motion.div className="hero-art" initial={reduced ? false : { opacity: 0, scale: .95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .8, delay: .1 }}><div className="portrait-backdrop" /><div className="portrait-type" aria-hidden="true">a.</div><div className="portrait-frame"><img src={asset('images/profile/portrait.webp')} alt="Adarsha Vimukthikani" width="1000" height="1250" fetchPriority="high" /></div><div className="portrait-caption"><span className="mono">CURRENTLY EXPLORING</span><strong>Marketing.<br />People. Possibilities.</strong></div><span className="portrait-edition mono">MANAGEMENT UNDERGRADUATE<br />UNIVERSITY OF RUHUNA</span></motion.div>
      </div><div className="hero-bottom"><RouteLink to="/about">A little more about me</RouteLink><span className="mono">MARKETING STUDENT · CREATIVE THINKER</span></div>
    </section>
    <div className="marquee" role="region" aria-label={words.join(', ')}><div className="marquee-track" aria-hidden="true">{[0, 1].map(copy => <div className="marquee-group" key={copy}>{words.map(word => <span key={word}>{word}<i>✳</i></span>)}</div>)}</div></div>
    <section className="home-intro shell section-pad"><Reveal><Eyebrow number="01">A SHORT INTRODUCTION</Eyebrow></Reveal><Reveal className="intro-grid"><h2>Business thinking.<br /><span className="serif-word">A human perspective.</span></h2><div><p>I’m interested in why people connect with a brand, and how a thoughtful idea becomes a clear message. My studies in Management and Marketing give those questions a practical foundation.</p><RouteLink to="/about">Read my story</RouteLink></div></Reveal></section>
    <section className="home-focus shell"><Reveal className="home-focus-visual" variant="image"><BrandBoard small /></Reveal><Reveal className="home-focus-copy" variant="slide"><Eyebrow number="02">MY DEVELOPING PRACTICE</Eyebrow><h2>Ideas with<br /><span className="serif-word">a purpose.</span></h2><div className="focus-lines"><span>01 <strong>Branding & visual storytelling</strong></span><span>02 <strong>Marketing & business thinking</strong></span><span>03 <strong>Creative communication</strong></span></div><RouteLink to="/skills">Explore my skills & tools</RouteLink></Reveal></section>
    <section className="home-journey shell section-pad"><Reveal className="home-work-preview"><div><span className="mono">UNIVERSITY INVOLVEMENT</span><h2>Public Relations<br />Coordinator</h2><p>Circle of Marketing · University of Ruhuna</p><RouteLink to="/work">Explore my experience</RouteLink></div><BrandLogo brand="circle-of-marketing" /></Reveal><Reveal className="home-education-preview"><div><span className="mono">LEARNING IN TWO PLACES</span><h3>Academic grounding.<br />Professional curiosity.</h3><p>Management, specializing in Marketing.<br />CIM Level 4 student.</p><RouteLink to="/education">View my education</RouteLink></div><div className="education-logo-pair"><BrandLogo brand="ruhuna" /><BrandLogo brand="cim" /></div></Reveal></section>
    <section className="home-writing shell"><Reveal className="preview-heading"><div><Eyebrow number="03">FROM MY NOTEBOOK</Eyebrow><h2>Thinking about brands.</h2></div><RouteLink to="/articles">Read my articles</RouteLink></Reveal><Reveal className="home-article" variant="image"><a href={featured.url} target="_blank" rel="noopener noreferrer" className="article-cover"><img src={asset(`images/articles/${featured.image}`)} alt="Nike campaign article cover" width="900" height="600" loading="lazy" /></a><div><span className="mono">{featured.category}</span><h3><a href={featured.url} target="_blank" rel="noopener noreferrer">{featured.title}</a></h3><p>{featured.description}</p><a className="arrow-link" href={featured.url} target="_blank" rel="noopener noreferrer">Read on Medium<ArrowUpRight size={18} aria-hidden="true" /></a></div><ArrowDownRight className="article-corner" size={56} strokeWidth={1} aria-hidden="true" /></Reveal></section>
    <ContactCTA />
  </div>;
}
