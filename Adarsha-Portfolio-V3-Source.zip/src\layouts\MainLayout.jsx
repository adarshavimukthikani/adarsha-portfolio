import { useLayoutEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { navigation } from '../data/navigation';
import { profile } from '../data/profile';

export default function MainLayout({ children }) {
  const { pathname } = useLocation();
  const main = useRef(null);
  const page = navigation.find(item => item.href === pathname);
  useLayoutEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    main.current?.focus({ preventScroll: true });
    document.title = `${page?.label || 'Page not found'} | ${profile.name}`;
    const description = document.querySelector('meta[name="description"]');
    if (description) description.content = page?.description || 'Explore the portfolio of Adarsha Vimukthikani.';
  }, [pathname, page]);
  return <><a href="#main-content" className="skip-link">Skip to content</a><Navbar /><main ref={main} id="main-content" tabIndex={-1}>{children}</main><Footer /></>;
}
