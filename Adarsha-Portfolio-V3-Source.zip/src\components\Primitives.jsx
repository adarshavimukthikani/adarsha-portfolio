import { m as motion, useReducedMotion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Reveal({ children, className = '', delay = 0, variant = 'rise' }) {
  const reduced = useReducedMotion();
  const initial = variant === 'image' ? { opacity: 0, scale: .97, clipPath: 'inset(7% 0 0 0)' } : variant === 'slide' ? { opacity: 0, x: 20 } : { opacity: 0, y: 22 };
  return <motion.div className={className} initial={reduced ? false : initial} whileInView={{ opacity: 1, y: 0, x: 0, scale: 1, clipPath: 'inset(0% 0 0 0)' }} viewport={{ once: true, amount: 0.12 }} transition={{ duration: reduced ? 0 : 0.65, delay: reduced ? 0 : delay, ease: [0.22,1,0.36,1] }}>{children}</motion.div>;
}
export function Eyebrow({ number, children }) {
  return <div className="eyebrow"><span className="section-number">{number}</span><span>{children}</span></div>;
}
export function ArrowLink({ href, children, className = '', external = false, ...props }) {
  return <a href={href} className={`arrow-link ${className}`} {...(external ? {target:'_blank',rel:'noopener noreferrer'} : {})} {...props}>{children}<ArrowUpRight size={19} aria-hidden="true" /></a>;
}
export function Brand({ footer = false }) {
  return <Link className={`brand ${footer ? 'brand-footer' : ''}`} to="/" title="Home"><span className="brand-symbol" aria-hidden="true">a<span>·</span></span><span>adarsha<span className="brand-dot">.</span></span><span className="sr-only"> Home</span></Link>;
}
export function Spark({ className = '' }) {
  return <svg className={className} viewBox="0 0 80 80" fill="none" aria-hidden="true"><path d="M40 3v74M3 40h74M14 14l52 52M14 66l52-52" stroke="currentColor" strokeWidth="9" strokeLinecap="round" /></svg>;
}
