import { BrowserRouter } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import AppRoutes from './app/router';

export default function App() {
  return <BrowserRouter><MainLayout><AppRoutes /></MainLayout></BrowserRouter>;
}
