import { PageHeading, RouteLink } from '../components/PageUI';

export default function NotFound() {
  return <div className="not-found shell page-pad" data-page="not-found"><span className="error-number" aria-hidden="true">404</span><PageHeading number="?" label="PAGE NOT FOUND" title={<>A small detour.<br /><span className="serif-word">Let’s head back.</span></>}>That page isn’t here. You can return home or explore my articles.</PageHeading><div className="not-found-actions"><RouteLink to="/" button>Back to Home</RouteLink><RouteLink to="/articles">Read my articles</RouteLink></div></div>;
}
