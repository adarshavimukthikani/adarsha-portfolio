import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { Eyebrow, Reveal } from './Primitives';

export function RouteLink({ to, children, className = '', button = false }) {
  return <Link to={to} className={`${button ? 'button button-primary' : 'arrow-link'} ${className}`}>{children}<ArrowUpRight size={18} aria-hidden="true" /></Link>;
}
export function PageHeading({ number, label, title, children, className = '' }) {
  return <Reveal className={`page-heading ${className}`}><Eyebrow number={number}>{label}</Eyebrow><h1>{title}</h1>{children && <p className="page-deck">{children}</p>}</Reveal>;
}
export function ContactCTA({ compact = false }) {
  return <section className={`contact-cta shell ${compact ? 'compact' : ''}`}><Reveal><div className="cta-inner"><div><span className="mono">LET’S CONNECT</span><h2>A conversation<br />is a good place to start.</h2></div><RouteLink to="/contact" button>Get in touch</RouteLink></div></Reveal></section>;
}
