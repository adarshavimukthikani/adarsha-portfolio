import { NavLink, useLocation } from 'react-router-dom';
import { ArrowUp, ArrowUpRight } from 'lucide-react';
import { Brand } from './Primitives';
import { profile } from '../data/profile';

export default function Footer() {
  const { pathname } = useLocation();
  return <footer className="site-footer shell"><div className="footer-main"><Brand footer /><p>Marketing. Business.<br />A creative perspective.</p><nav aria-label="Footer navigation"><NavLink to="/about">About</NavLink><NavLink to="/education">Education</NavLink><NavLink to="/articles">Articles</NavLink><NavLink to="/contact">Contact</NavLink><a href={profile.linkedin} target="_blank" rel="noopener noreferrer">LinkedIn<ArrowUpRight size={13} aria-hidden="true" /></a></nav><button className="back-top icon-button" type="button" onClick={() => { const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches; window.scrollTo({ top: 0, behavior: reduced ? 'instant' : 'smooth' }); }} aria-label="Back to top"><ArrowUp size={20} aria-hidden="true" /></button></div><div className="footer-bottom"><span>© {new Date().getFullYear()} {profile.name}</span><span className="mono">{pathname === '/' ? 'BUSINESS × CREATIVITY' : 'A CONTINUING JOURNEY'}</span><span>Built with care. Open to learning.</span></div></footer>;
}
